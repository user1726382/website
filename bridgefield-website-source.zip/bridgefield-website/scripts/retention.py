"""Retention housekeeping. Run from project root via cron after legal retention approval.
Dry run is the default. Use --apply to actually delete expired records and files.
"""
import argparse, datetime, os, pathlib, sys
from dotenv import load_dotenv
ROOT=pathlib.Path(__file__).resolve().parents[1]
load_dotenv(ROOT/'.env')
sys.path.insert(0,str(ROOT))
import database as db
p=pathlib.Path(os.getenv('DB_PATH','data/bridgefield.sqlite3'))
db.DB_PATH=str(p if p.is_absolute() else ROOT/p)
UPLOAD_DIR=pathlib.Path(os.getenv('UPLOAD_DIR','private_uploads'))
UPLOAD_DIR=(UPLOAD_DIR if UPLOAD_DIR.is_absolute() else ROOT/UPLOAD_DIR).resolve()

parser=argparse.ArgumentParser()
parser.add_argument('--applications-days',type=int,default=180)
parser.add_argument('--inquiries-days',type=int,default=365)
parser.add_argument('--apply',action='store_true')
args=parser.parse_args()
if not (1<=args.applications_days<=3650 and 1<=args.inquiries_days<=3650):raise SystemExit('Choose valid approved retention periods')
now=datetime.datetime.now(datetime.timezone.utc)
for kind,days in [('applications',args.applications_days),('inquiries',args.inquiries_days)]:
 cutoff=(now-datetime.timedelta(days=days)).isoformat()
 rows=db.many(f'SELECT * FROM {kind} WHERE created_at < ?',(cutoff,))
 print(f'{kind}: {len(rows)} records older than {days} days (apply={args.apply})')
 if not args.apply:continue
 for row in rows:
  if kind=='applications':
   file=pathlib.Path(row['file_path']).resolve()
   if file.parent!=UPLOAD_DIR:
    print('Skipping record with unexpected file path',row['id'])
    continue
   file.unlink(missing_ok=True)
  db.execute(f'DELETE FROM {kind} WHERE id=?',(row['id'],))
  db.execute('INSERT INTO admin_audit(id,created_at,action,record_id) VALUES(?,?,?,?)',
       (__import__('uuid').uuid4().hex,now.isoformat(),'retention.'+kind,row['id']))
