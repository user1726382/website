"""Create/disable a role-based admin account on the hosting server.
Examples:
 python scripts/manage_user.py create editor --role content
 python scripts/manage_user.py disable editor
"""
import sys, pathlib, argparse, getpass
from dotenv import load_dotenv
from argon2 import PasswordHasher
ROOT=pathlib.Path(__file__).resolve().parents[1]
load_dotenv(ROOT/'.env')
sys.path.insert(0,str(ROOT))
import database as db
import os
p=pathlib.Path(os.getenv('DB_PATH','data/bridgefield.sqlite3'))
db.DB_PATH=str(p if p.is_absolute() else ROOT/p)
db.init()
parser=argparse.ArgumentParser()
parser.add_argument('command',choices=['create','disable','enable'])
parser.add_argument('username')
parser.add_argument('--role',choices=['admin','content','marketing','recruitment'],default='content')
args=parser.parse_args()
if not args.username.replace('_','').replace('-','').isalnum() or len(args.username)>40:raise SystemExit('Invalid username')
if args.command=='create':
 password=getpass.getpass('Password (12+ characters): ')
 if len(password)<12:raise SystemExit('Use a password of at least 12 characters')
 hashval=PasswordHasher().hash(password)
 db.execute('INSERT INTO users(username,password_hash,role,enabled) VALUES(?,?,?,1) ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash,role=excluded.role,enabled=1',(args.username,hashval,args.role))
 print(f'Created/updated {args.role} user: {args.username}')
else:
 db.execute('UPDATE users SET enabled=? WHERE username=?',(1 if args.command=='enable' else 0,args.username))
 print('Updated account:',args.username,args.command)
