import secrets, getpass
from argon2 import PasswordHasher
print('SESSION_SECRET=' + secrets.token_urlsafe(48))
print('ADMIN_PASSWORD_HASH=' + PasswordHasher().hash(getpass.getpass('Choose admin password: ')))
