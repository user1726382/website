import os, re, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from fastapi.testclient import TestClient
from argon2 import PasswordHasher
import database as db
import app as site
from content import PATHS,url

@pytest.fixture
def client(tmp_path,monkeypatch):
    site.rate_state.clear()
    db.DB_PATH=str(tmp_path/'database.sqlite3')
    site.UPLOAD_DIR=tmp_path/'uploads'
    site.UPLOAD_DIR.mkdir()
    site.ADMIN_HASH=PasswordHasher().hash('strong-test-password')
    monkeypatch.setenv('SESSION_SECRET','fixed-test-secret')
    monkeypatch.setenv('ACCEPT_INQUIRIES','true')
    monkeypatch.setenv('ACCEPT_APPLICATIONS','true')
    monkeypatch.setenv('CV_SCAN_MODE','off')
    with TestClient(site.app) as c:yield c

def csrf(html):
    match=re.search(r'name="csrf" value="([^"]+)"',html)
    assert match
    return match.group(1)

def admin(client):
    t=csrf(client.get('/admin/login').text)
    response=client.post('/admin/login',data={'csrf':t,'username':'admin','password':'strong-test-password'},follow_redirects=False)
    assert response.status_code==303


def test_all_public_pages_both_languages(client):
    for ident in PATHS:
        for loc in ('en','de'):
            r=client.get(url(loc,ident))
            assert r.status_code==200,(ident,loc,r.text[:200])
            assert '<html lang="'+loc+'">' in r.text
            assert '<title>' in r.text

def test_site_meta_and_security(client):
    r=client.get('/en/')
    assert 'Content-Security-Policy' in r.headers
    assert 'cross-border' in r.text.lower()
    assert 'hreflang="de"' in r.text
    assert client.get('/admin/jobs').status_code==403
    assert client.get('/en/does-not-exist').status_code==404
    assert 'Disallow: /admin/' in client.get('/robots.txt').text
    assert 'sitemap' in client.get('/sitemap.xml').text

def test_inquiry_and_csrf(client):
    r=client.get('/en/contact')
    token=csrf(r.text)
    values={'csrf':token,'locale':'en','kind':'general','name':'Example User','email':'hello@company.test','company':'Example Ltd','message':'We want expansion help','service':'market-entry','privacy_read':'on'}
    bad=client.post('/forms/inquiry',data={**values,'csrf':'invalid'})
    assert bad.status_code==403
    accepted=client.post('/forms/inquiry',data=values,follow_redirects=False)
    assert accepted.status_code==303
    assert accepted.headers['location']=='/en/thank-you'
    item=db.one('SELECT * FROM inquiries WHERE email=?',('hello@company.test',))
    assert item['service']=='market-entry'
    assert item['status']=='new'

def test_candidate_validation_and_private_storage(client):
    token=csrf(client.get('/en/for-candidates').text)
    fields={'csrf':token,'locale':'en','name':'Jane Example','email':'jane@example.test','privacy_read':'on'}
    invalid=client.post('/forms/apply',data=fields,files={'cv':('cv.pdf',b'not-a-pdf','application/pdf')})
    assert invalid.status_code==422
    valid=client.post('/forms/apply',data=fields,files={'cv':('resume.pdf',b'%PDF-1.7\n% demo pdf content\n','application/pdf')},follow_redirects=False)
    assert valid.status_code==303
    item=db.one('SELECT * FROM applications WHERE email=?',('jane@example.test',))
    assert item is not None
    assert Path(item['file_path']).exists()
    assert client.get('/admin/cv/'+item['id']).status_code==403
    admin(client)
    assert client.get('/admin/cv/'+item['id']).status_code==200
    token=csrf(client.get('/admin/applications').text)
    result=client.post('/admin/submissions/delete',data={'csrf':token,'kind':'applications','id':item['id'],'confirm':'DELETE'},follow_redirects=False)
    assert result.status_code==303
    assert db.one('SELECT id FROM applications WHERE id=?',(item['id'],)) is None
    assert not Path(item['file_path']).exists()

def test_admin_job_publishing_and_editing(client):
    admin(client)
    token=csrf(client.get('/admin/jobs/new').text)
    data={'csrf':token,'slug':'business-development-manager','title_en':'Business Development Manager','title_de':'Business Development Manager/in','location':'Dublin','country':'Ireland','category':'Sales','employment_type':'Permanent','description_en':'Live vacancy for an approved client.','description_de':'Aktuelle Stellenanzeige eines Kunden.','published':'on'}
    response=client.post('/admin/jobs/save',data=data,follow_redirects=False)
    assert response.status_code==303
    assert client.get('/en/jobs/business-development-manager').status_code==200
    assert client.get('/de/stellenangebote/business-development-manager').status_code==200
    assert 'business-development-manager' in client.get('/en/jobs').text
    assert db.one('SELECT COUNT(*) AS n FROM admin_audit')['n']>=2

def test_admin_page_edits(client):
    admin(client)
    r=client.get('/admin/pages/recruitment')
    token=csrf(r.text)
    values={'csrf':token,'en_title':'A better way to recruit','de_title':'Besser rekrutieren'}
    assert client.post('/admin/pages/recruitment',data=values,follow_redirects=False).status_code==303
    assert 'A better way to recruit' in client.get('/en/services/recruitment').text
    assert 'Besser rekrutieren' in client.get('/de/leistungen/personalvermittlung').text

def test_unconfigured_forms_are_blocked(client,monkeypatch):
    monkeypatch.setenv('ACCEPT_INQUIRIES','false')
    page=client.get('/en/contact')
    assert 'disabled title=' in page.text
    response=client.post('/forms/inquiry',data={'csrf':csrf(page.text),'name':'X','email':'x@y.com','message':'Example','privacy_read':'on'})
    assert response.status_code==503

def test_role_based_access(client):
    db.execute('INSERT INTO users(username,password_hash,role,enabled) VALUES (?,?,?,1)',('recruiter',PasswordHasher().hash('recruiter-long-password'),'recruitment'))
    token=csrf(client.get('/admin/login').text)
    response=client.post('/admin/login',data={'csrf':token,'username':'recruiter','password':'recruiter-long-password'},follow_redirects=False)
    assert response.status_code==303
    dashboard=client.get('/admin')
    assert dashboard.status_code==200
    assert 'Applications' in dashboard.text
    assert 'inquiries' not in dashboard.text.lower()
    assert client.get('/admin/jobs').status_code==200
    assert client.get('/admin/media').status_code==403
    assert client.get('/admin/inquiries').status_code==403
    assert client.get('/admin/settings').status_code==403
    assert client.get('/admin/applications').status_code==200


def test_media_upload_and_article_assignment(client):
    import io
    from PIL import Image
    admin(client)
    t=csrf(client.get('/admin/media').text)
    im=Image.new('RGB',(100,80),'#487b73');buf=io.BytesIO();im.save(buf,format='PNG')
    resp=client.post('/admin/media',data={'csrf':t,'alt_text':'Original branded photo'},files={'image':('photo.png',buf.getvalue(),'image/png')},follow_redirects=False)
    assert resp.status_code==303
    asset=db.one('SELECT * FROM media LIMIT 1')
    assert asset and asset['file_name'].endswith('.webp')
    assert client.get('/media/'+asset['file_name']).status_code==200
    article=db.one('SELECT id FROM articles LIMIT 1')
    art_form=client.get('/admin/articles/'+article['id'])
    assert 'Original branded photo' in art_form.text
    assert client.get('/admin').status_code==200


def test_local_links_resolve(client):
    from html.parser import HTMLParser
    class Links(HTMLParser):
        def __init__(self):super().__init__();self.urls=[]
        def handle_starttag(self,tag,attrs):
            if tag=='a':
                values=dict(attrs);v=values.get('href')
                if v and v.startswith('/') and not v.startswith('//'):self.urls.append(v.split('#')[0])
    for ident in PATHS:
        for locale in ('en','de'):
            response=client.get(url(locale,ident))
            parser=Links();parser.feed(response.text)
            for link in set(parser.urls):
                if not link:continue
                assert client.get(link).status_code not in (404,500),(ident,locale,link)

def test_home_and_legal_content_editor(client):
    admin(client)
    token=csrf(client.get('/admin/pages/home').text)
    r=client.post('/admin/pages/home',data={'csrf':token,'en_title':'A revised homepage title','de_title':'Ein überarbeiteter Titel'},follow_redirects=False)
    assert r.status_code==303
    assert 'A revised homepage title' in client.get('/en/').text
    assert 'Ein überarbeiteter Titel' in client.get('/de/').text
    token=csrf(client.get('/admin/pages/privacy').text)
    r=client.post('/admin/pages/privacy',data={'csrf':token,'en_body':'New verified privacy copy','de_body':'Neue geprüfte Datenschutzhinweise'},follow_redirects=False)
    assert r.status_code==303
    assert 'New verified privacy copy' in client.get('/en/legal/privacy').text
    assert 'Neue geprüfte Datenschutzhinweise' in client.get('/de/rechtliches/datenschutz').text


def test_schema_is_off_until_verification(client,monkeypatch):
    assert 'application/ld+json' not in client.get('/en/').text
    monkeypatch.setenv('PUBLISH_STRUCTURED_DATA','true')
    home=client.get('/en/')
    assert 'application/ld+json' in home.text
    service=client.get('/en/services/recruitment')
    assert 'schema.org' in service.text
    article=client.get('/en/insights/expanding-to-germany')
    assert 'schema.org' in article.text


def test_settings_https_guard(client):
    admin(client)
    t=csrf(client.get('/admin/settings').text)
    r=client.post('/admin/settings',data={'csrf':t,'booking_url':'javascript:alert(1)','contact_email':'hello@test.io'})
    assert r.status_code==422
    r=client.post('/admin/settings',data={'csrf':t,'site_name':'Verified Advisory Ltd','brand_wordmark':'verified','contact_email':'hello@test.io','booking_url':'https://cal.com/example'},follow_redirects=False)
    assert r.status_code==303
    html=client.get('/en/').text
    assert 'Verified Advisory Ltd' in html
    assert 'https://cal.com/example' in html
