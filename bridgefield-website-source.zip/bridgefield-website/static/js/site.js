(()=>{
  const toggle=document.querySelector('.mobile-toggle'),menu=document.querySelector('#mobile-menu');
  if(toggle && menu)toggle.addEventListener('click',()=>{const isOpen=toggle.getAttribute('aria-expanded')==='true';toggle.setAttribute('aria-expanded',String(!isOpen));menu.hidden=isOpen;document.body.classList.toggle('menu-open',!isOpen)});
  const header=document.querySelector('.site-header');
  if(header)window.addEventListener('scroll',()=>header.classList.toggle('scrolled',window.scrollY>15),{passive:true});
  const jobSearch=document.querySelector('#job-search'),jobCountry=document.querySelector('#job-country'),jobType=document.querySelector('#job-type');
  const filterJobs=()=>{const rows=[...document.querySelectorAll('.job-row')];let n=0;rows.forEach(r=>{const show=(!jobSearch.value||r.dataset.search.includes(jobSearch.value.toLowerCase()))&&(!jobCountry.value||r.dataset.country===jobCountry.value)&&(!jobType.value||r.dataset.type===jobType.value);r.hidden=!show;if(show)n++});const empty=document.querySelector('#job-no-match');if(empty)empty.hidden=n!==0||!rows.length};
  [jobSearch,jobCountry,jobType].forEach(el=>el?.addEventListener('input',filterJobs));
  document.querySelectorAll('#article-filters button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#article-filters button').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelectorAll('#articles-grid .article-card').forEach(c=>c.hidden=b.dataset.filter!=='all'&&c.dataset.category!==b.dataset.filter)}));
  const banner=document.querySelector('#cookie-banner'),modal=document.querySelector('#cookie-modal');
  const consentKey='bridgefield-cookie-choice-v1';
  let choice=null;try{choice=localStorage.getItem(consentKey)}catch(e){}
  if(banner&&!choice)banner.hidden=false;
  function save(optional){try{localStorage.setItem(consentKey,JSON.stringify({optional,at:new Date().toISOString()}))}catch(e){}if(banner)banner.hidden=true;if(modal)modal.hidden=true;}
  document.querySelectorAll('.cookie-reject').forEach(x=>x.addEventListener('click',()=>save(false)));
  document.querySelectorAll('.cookie-accept').forEach(x=>x.addEventListener('click',()=>save(true)));
  document.querySelectorAll('.cookie-manage,.cookie-open').forEach(x=>x.addEventListener('click',()=>{if(modal){modal.hidden=false;const cb=modal.querySelector('#analytics-consent');if(cb)cb.focus()}}));
  document.querySelectorAll('.cookie-close').forEach(x=>x.addEventListener('click',()=>modal.hidden=true));
  document.querySelectorAll('.cookie-save').forEach(x=>x.addEventListener('click',()=>save(Boolean(document.querySelector('#analytics-consent')?.checked))));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal)modal.hidden=true});
  // No analytics scripts ship with this site. Consent storage alone does not start tracking.
})();
